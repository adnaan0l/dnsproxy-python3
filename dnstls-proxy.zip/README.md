# Simple DNS over TLS daemon  

Simple daemon that listens to DNS queries made to udp/53 and tcp/53.
Redirects to a DNS server that supports TLS over an encrypted channel for privacy.
Works over plain-text if requred. (by setting)
Runs using multithreaded servers and accept multiples requests.

## Requirements
* Python3
* Docker

## Usage

  Build the image using the Dockerfile
  ```
  $ docker build -t="dnstls" .
  $ docker run --rm -p 53:53/tcp -p 53:53/udp dnstls
  ```
  
  You may set new values for configuration (dns server, secure-udp) using the
  flags options.
  
  Options:
  -  --dns-server TEXT  Upstream DNS server to query -   [default: 1.0.0.1]
  -  --secure-udp TEXT  Option to send UDP queries over TLS instead of in plain-text [default: true]
  
  Example:
  ```
  docker run --rm -p 53:53/tcp -p 53:53/udp dnstls --dns-server=cloudflare --secure-udp=true
  ```

## Testing
  After starting the proxy, you can test a DNS request using Dig.
  Query using UDP:
  ```
  $ dig @127.0.0.1 google.com
  ```
  Query using TCP:
  ```
  $ dig @127.0.0.1 google.com +tcp
  ```
  For multiple requests, run from project root 
  ```
  cd tests
  ./queryflood.sh 
  ```

## Implementation and Choices
  - This was my first time working on a network component in Python. So, there was a steep learning curve but I really enjoyed the challenge and the overall learning process.
  - I started by spending the first day researching references to get a better understnding of the problem and also looking for potential solutions that would ease development and prevent reinventing the wheel. Through this I was able to find few similar reference solutions as well as the socketserver library for Python.
  - I then used the socketserver documentation to build a basic TCP requets handler and a Threaded TCP Server using the ThreadMixin class to be able to handle multiple requests at the same time. Once tested, I also built and tested a UDP Threaded server with a basic UDP request handler. The basic request handling at this point was to return the received text after converting to capital case. The ability to deploy these servers and handlers using a builtin class and methods with minimal code saved time and gave me the opportunity to focus on the other implementations.   
  - Once the servers were functioning, I started working on the TCP request handler receiving DNS queries from the TCP Threaded server listening on tcp\853 for testing purposes. Along with the request handler, I also started working on the Python methods to query an upstream DNS server using the Python ssl and socket library.
  - Once the proxy was able to handle DNS queries over TCP, I configured the UDP request handler listening on udp\853 as above and updated the query methods to handle the request and response to suit UDP standards while still querying over TLS to the upstream server. 
  - Then, I worked on refactoring, simplfying and cleaning up the code, error logging using the Python logging library with logs written to the output stream as well as log files within the proxy server. 
  -  After this was completed, I built a method to handle upstream queries over UDP in plain-text with the option to turn on or off with a --secure-udp argument on the docker container. And also a --dns-server argument to specify which upstream server to use (current options for cloudflare, google).
  
## Improvements
  Few improvements I could think of,
  - Properly configuring the servers to not close TCP connections immediately and handle connections as described in the DNS RFC.
  - Create a sync between the two TCP connections of the same session, client-->daemon and daemon-->upstream-server. So that the same connections would be used until closed by the client or a timeout occurs.
  - Parsing answers to DNS queres and better error logging.
  - Caching to speed up response times while reducing server load and unnecessary requests the the upstream server.

## Questions

  * Imagine this proxy being deployed in an infrastructure. What would be the security concerns you would raise?
  - That the presence of a load balancer or firewall with DDoS protection capabilities fronting the DNS server is required along with sufficient scaling capabilities. Since DDoS is a common vulnerability of DNS servers.
  - That the servers itself are properly hardened according to the latest security developments. Having an automated pipeline applying patches and security updates without delay.
  - That only the absolutely necessary ports are opened and allowed for communication.


  * How would you integrate that solution in a distributed, microservices-oriented and containerized architecture?
  - I believe a Canary Deployment would be well suited. Mainly because a DNS is a critical service and always receives high amounts of traffic. Through a Canary Deployment, we can initially work with lower traffic volumes to monitor the solution for performance or any issues that might come up and also work on potential fixes or upgrades. If we like how the solution is behaving, we can gradually increase the traffic coming into to the solution until we have a 100% of the traffic.    


  * What other improvements do you think would be interesting to add to the project?
  - A DNS over HTTPS(DoH) implementation.
  - Maybe a serverless implementation.
  - A proactive security implementation to control redirections(eg. blocking redirections to potentially malicious urls).
  - Implementations for traffic management and routing(eg. facilitate microservices deployment strategies).
